﻿using UnityEngine;
using TMPro;

public class ARPixelDetector : MonoBehaviour
{
    public TextMeshProUGUI resultText;

    public void Detect()
    {
        resultText.text = "Scanning...";

        Texture2D tex = ScreenCapture.CaptureScreenshotAsTexture();
        Color[] pixels = tex.GetPixels();

        float greenScore = 0f;
        float brownScore = 0f;
        int validPixels = 0;

        foreach (Color p in pixels)
        {
            float brightness = (p.r + p.g + p.b) / 3f;
            if (brightness < 0.2f || brightness > 0.9f)
                continue;

            validPixels++;

            // green detection
            if (p.g > p.r && p.g > p.b)
                greenScore++;

            // brown/disease detection
            if (p.r > p.g && p.r > p.b)
                brownScore++;
        }

        if (validPixels == 0)
        {
            resultText.text = "No plant detected";
            return;
        }

        float greenRatio = greenScore / validPixels;
        float brownRatio = brownScore / validPixels;

        if (greenRatio > 0.5f)
            resultText.text = "The plant is healthy";
        else if (brownRatio > 0.4f)
            resultText.text = "The plant is diseased";
        else
            resultText.text = "Unclear, Scan Again";

        Destroy(tex);
    }
}